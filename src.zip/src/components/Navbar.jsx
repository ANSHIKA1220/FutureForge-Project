import { useState } from 'react';

function Navbar({ scrolled }) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
      <div className="nav-content">
        {/* Left side of the navbar - Platform Name */}
        <div className="nav-left">
          <div className="platform-name">NeuroVision</div>
        </div>

        {/* Right side of the navbar - Menu Links */}
        <div className="nav-right">
          <div className="nav-links">
            <a href="#products" className="nav-item">Products</a>
            <a href="#research" className="nav-item">Research</a>
            <a href="#contactUs" className="nav-item">Contact Us</a>
          </div>

          {/* Mobile menu button */}
          <button className="menu-btn" onClick={() => setMenuOpen(!menuOpen)}>
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </div>

      {/* Mobile menu (shown when menuOpen is true) */}
      {menuOpen && (
        <div className="mobile-menu">
          <a href="#products">Products</a>
          <a href="#research">Research</a>
          <a href="#contactUs">Contact Us</a>
        </div>
      )}
    </nav>
  );
}

export default Navbar;
